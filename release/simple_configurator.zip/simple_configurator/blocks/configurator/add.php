<?php

defined("C5_EXECUTE") or die("Access Denied.");

use Concrete\Core\View\View;

/** @var View $this */

/** @noinspection PhpUnhandledExceptionInspection */
$this->inc("edit.php");